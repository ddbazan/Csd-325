from django.apps import AppConfig


class MyappbazanConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'myappbazan'
